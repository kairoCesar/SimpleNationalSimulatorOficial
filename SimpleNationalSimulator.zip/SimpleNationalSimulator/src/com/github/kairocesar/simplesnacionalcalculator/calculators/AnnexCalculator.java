package com.github.kairocesar.simplesnacionalcalculator.calculators;

import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexOne;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexThree;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexTwo;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AbstractAnnex;
import com.github.kairocesar.simplesnacionalcalculator.taxdistribution.Tax;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class AnnexCalculator {

    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
    private final NumberFormat percentFormat = new DecimalFormat("#.###%");

    private TaxCalculator taxCalc;

    public AnnexCalculator(TaxCalculator taxCalc) {
        this.taxCalc = taxCalc;
    }

    public void calculateTax() {
        double totalValue = 0;
        for (Tax tax : taxCalc.getTaxes()) {
            System.out.printf("%s aliquot: %s - value: %s %n", tax.name(), percentFormat.format(tax.aliquot()),
                    currencyFormat.format(tax.aliquot() * taxCalc.salesValue()));
            totalValue += tax.aliquot() * taxCalc.salesValue();
        }
        System.out.printf("Total value: %s%nGeneral aliquot: %s", currencyFormat.format(taxCalc.salesValue() *
                taxCalc.getGeneralAliquot()), percentFormat.format(taxCalc.getGeneralAliquot()));
    }
}
