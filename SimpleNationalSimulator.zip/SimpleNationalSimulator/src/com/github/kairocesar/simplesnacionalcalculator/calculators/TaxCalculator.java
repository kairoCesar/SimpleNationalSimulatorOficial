package com.github.kairocesar.simplesnacionalcalculator.calculators;

import com.github.kairocesar.simplesnacionalcalculator.annexes.AbstractAnnex;
import com.github.kairocesar.simplesnacionalcalculator.taxdistribution.Tax;

public record TaxCalculator (AbstractAnnex annex, double rbt12, double salesValue) {

    public double getGeneralAliquot() {
        int range = annex.getRange(rbt12());
        double deductionValue = annex.getDeductionValues(range);
        return (((rbt12 * annex.getAliquots(range)) - deductionValue) / rbt12);
    }

    public Tax[] getTaxes() {
        return annex().getTaxDistribution(annex.getRange(rbt12()), getGeneralAliquot());
    }
}
