package com.github.kairocesar.simplesnacionalcalculator.taxdistribution;

public record Tax(String name, double aliquot) {
}
