package com.github.kairocesar.simplesnacionalcalculator.panel;

import com.github.kairocesar.simplesnacionalcalculator.annexes.AbstractAnnex;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexOne;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexThree;
import com.github.kairocesar.simplesnacionalcalculator.annexes.AnnexTwo;
import com.github.kairocesar.simplesnacionalcalculator.calculators.AnnexCalculator;
import com.github.kairocesar.simplesnacionalcalculator.calculators.TaxCalculator;

import java.util.Scanner;

public class UserPanel {

    private static AbstractAnnex[] annexes = {new AnnexOne(), new AnnexTwo(), new AnnexThree()};
    private static Scanner input = new Scanner(System.in);

    public static void buildTaxCalculator() {
        AnnexCalculator annexCalculator = new AnnexCalculator(new TaxCalculator(getAnnex(), getRbt12(), getSalesValue()));
        annexCalculator.calculateTax();
    }

    private static AbstractAnnex getAnnex() {
        System.out.print("Annex: ");
        return annexes[input.nextInt() - 1];
    }

    private static double getRbt12() {
        System.out.print("RBT12: ");
        return input.nextDouble();
    }

    private static double getSalesValue() {
        System.out.print("Sales value: ");
        return input.nextDouble();
    }


}
