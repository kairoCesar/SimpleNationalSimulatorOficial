package com.github.kairocesar.simplesnacionalcalculator.annexes;

import com.github.kairocesar.simplesnacionalcalculator.annexes.AbstractAnnex;
import com.github.kairocesar.simplesnacionalcalculator.taxdistribution.Tax;

public class AnnexOne implements AbstractAnnex {

    public double getAliquots(int range) {
        double[] aliquots = {0.04, 0.0730, 0.0950, 0.1070, 0.1430, 0.19};
        return aliquots[range - 1];
    }

    public double getDeductionValues(int range) {
        double[] deductionValues = {0, 5940.00, 13860.00, 22500.00, 87300.00, 378000.00};
        return deductionValues[range - 1];
    }

    public Tax[] getTaxDistribution(int range, double generalAliquot) {
        double[] cpp = {0.4150, 0.4150, 0.42, 0.42, 0.42, 0.4210};
        double[] csll = {0.0350, 0.0350, 0.0350, 0.0350, 0.0350, 0.10};
        double[] irpj = {0.0550, 0.0550, 0.0550, 0.0550, 0.0550, 0.1350};
        double[] pis = {0.0276, 0.0276, 0.0276, 0.0276, 0.0276, 0.0613};
        double[] cofins = {0.1274, 0.1274, 0.1274, 0.1274, 0.1274, 0.2827};
        double[] icms = {0.34, 0.34, 0.3350, 0.3350, 0.3350, 0.3350};


        return new Tax[] {
                new Tax("CPP", generalAliquot * cpp[range - 1]),
                new Tax("CSLL", generalAliquot * csll[range - 1]),
                new Tax("IRPJ", generalAliquot * irpj[range - 1]),
                new Tax("PIS", generalAliquot * pis[range - 1]),
                new Tax("COFINS", generalAliquot * cofins[range - 1]),
                new Tax("ICMS", generalAliquot * icms[range - 1])
        };

    }

}

