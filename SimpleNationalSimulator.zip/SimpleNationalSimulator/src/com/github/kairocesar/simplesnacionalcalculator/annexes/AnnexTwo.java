package com.github.kairocesar.simplesnacionalcalculator.annexes;

import com.github.kairocesar.simplesnacionalcalculator.taxdistribution.Tax;

public class AnnexTwo implements AbstractAnnex {

    public double getAliquots(int range) {
        double[] aliquots = {0.0450, 0.0780, 0.10, 0.1120, 0.1470, 0.300};
        return aliquots[range - 1];
    }

    public double getDeductionValues(int range) {
        double[] deductionValues = {0, 5940.00, 13860.00, 22500.00, 85500.00, 720000.00};
        return deductionValues[range - 1];
    }

    public Tax[] getTaxDistribution(int range, double generalAliquot) {
        double[] cpp = {0.3750, 0.3750, 0.3750, 0.3750, 0.3750, 0.2350};
        double[] csll = {0.0350, 0.0350, 0.0350, 0.0350, 0.0350, 0.0750};
        double[] irpj = {0.0550, 0.0550, 0.0550, 0.0550, 0.0550, 0.0850};
        double[] pis = {0.0249, 0.0249, 0.0249, 0.0249, 0.0249, 0.0454};
        double[] cofins = {0.1151, 0.1151, 0.1151, 0.1151, 0.1151, 0.2096};
        double[] icms = {0.32, 0.32, 0.32, 0.32, 0.32, 0.32};


        return new Tax[] {
                new Tax("CPP", generalAliquot * cpp[range - 1]),
                new Tax("CSLL", generalAliquot * csll[range - 1]),
                new Tax("IRPJ", generalAliquot * irpj[range - 1]),
                new Tax("PIS", generalAliquot * pis[range - 1]),
                new Tax("COFINS", generalAliquot * cofins[range - 1]),
                new Tax("ICMS", generalAliquot * icms[range - 1])
        };
    }

}

