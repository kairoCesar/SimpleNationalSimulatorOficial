package com.github.kairocesar.simplesnacionalcalculator.annexes;

import com.github.kairocesar.simplesnacionalcalculator.taxdistribution.Tax;

public class AnnexThree implements AbstractAnnex{

    public double getAliquots(int range) {
        double[] aliquots = {0.06, 0.1120, 0.1350, 0.16, 0.21, 0.33};
        return aliquots[range - 1];
    }

    public double getDeductionValues(int range) {
        double[] deductionValues = {0, 9360.00, 17640.00, 35640.00, 125640.00, 648000.00};
        return deductionValues[range - 1];
    }

    public Tax[] getTaxDistribution(int range, double generalAliquot) {
        double[] cpp = {0.4340, 0.4340, 0.4340, 0.4340, 0.4340, 0.3050};
        double[] csll = {0.0350, 0.0350, 0.0350, 0.0350, 0.0350, 0.15};
        double[] irpj = {0.04, 0.04, 0.04, 0.04, 0.04, 0.35};
        double[] pis = {0.0278, 0.0305, 0.0296, 0.0296, 0.0278, 0.0347};
        double[] cofins = {0.1282, 0.1405, 0.1364, 0.1364, 0.1282, 0.1603};
        double[] iss = {0.3350, 0.32, 0.3250, 0.3250, 0.3350, 0.32};


        return new Tax[] {
                new Tax("CPP", generalAliquot * cpp[range - 1]),
                new Tax("CSLL", generalAliquot * csll[range - 1]),
                new Tax("IRPJ", generalAliquot * irpj[range - 1]),
                new Tax("PIS", generalAliquot * pis[range - 1]),
                new Tax("COFINS", generalAliquot * cofins[range - 1]),
                new Tax("ISS", generalAliquot * iss[range - 1])
        };
    }
}
